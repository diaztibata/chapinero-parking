<?php

error_reporting(0);

session_start();

if ((($_SESSION["codigo-parqueadero"] !== $_GET['codigoParqueadero']))) {

    if (($_SESSION["tipo"] !== "administrador")) {
        header("Location: index.php");
    }
}
$nombrepagina = "info-cp";
include 'views/header.php';
?>

<?php
include_once 'model/conexion.php';
$codigoParqueadero = $_GET['codigoParqueadero'];

$sentenciaPiso = $bd->prepare("select * from piso where codigo_parqueadero = ?;");
$sentenciaPiso->execute([$codigoParqueadero]);
$Piso = $sentenciaPiso->fetch(PDO::FETCH_OBJ);
//print($persona);
?>

<div class="middle-cp">
    <div class="tabla-parking">
        <h2>Lista Estacionamiento</h2>
        <div class="contenedor-tabla">
            <table>
                <thead>
                    <tr>
                        <th scope="col">Codigo</th>
                        <th scope="col">vehiculo</th>
                        <th scope="col">Estado</th>
                        <th scope="col">Costo minuto</th>
                        <th scope="col">Costo hora</th>
                        <th scope="col">Costo día</th>
                        <th scope="col">Costo mes</th>
                        <th scope="col">Hora Inicio</th>
                        <th scope="col">Placa</th>
                        <th scope="col">Opciones</th>
                    </tr>
                </thead>
                <tbody>

                    <?php

                    $sentenciaEstacionamiento  = $bd->prepare("select * from estacionamiento where codigo_parqueadero = ?;");
                    $sentenciaEstacionamiento->execute([$codigoParqueadero]);
                    $Estacionamiento  = $sentenciaEstacionamiento->fetchAll(PDO::FETCH_OBJ);

                    foreach ($Estacionamiento as $datoEstacionamiento) {
                    ?>

                        <tr>
                            <form method="POST" action="controller/estacionamiento/editar.php?codigo-estacionamiento=<?php echo $datoEstacionamiento->codigo_estacionamiento ?>&codigo-park=<?php echo $datoEstacionamiento->codigo_parqueadero ?>">
                                <td>
                                    <p><?php echo $datoEstacionamiento->numero_estacionamiento; ?></p>
                                </td>
                                <td>
                                    <p><?php echo $datoEstacionamiento->tipo_vehiculo; ?></p>
                                </td>
                                <td>
                                    <input type="text" name="txtEstado" style="pointer-events: none;" required value="<?php echo $datoEstacionamiento->estado; ?>">
                                </td>
                                <td>
                                    <input type="text" name="txtCostoMinuto" required value="<?php echo $datoEstacionamiento->costo_minuto; ?>">
                                </td>
                                <td>
                                    <input type="text" name="txtCostoHora" required value="<?php echo $datoEstacionamiento->costo_hora; ?>">
                                </td>
                                <td>
                                    <input type="text" name="txtCostoDia" required value="<?php echo $datoEstacionamiento->costo_dia; ?>">
                                </td>
                                <td>
                                    <input type="text" name="txtCostoMes" required value="<?php echo $datoEstacionamiento->costo_mes; ?>">
                                </td>
                                <td>
                                    <p><?php echo $datoEstacionamiento->hora_inicio; ?></p>
                                </td>
                                <td>
                                    <input type="text" name="txtCodigoVehiculo" required value="<?php echo $datoEstacionamiento->codigo_vehiculo; ?>">
                                </td>
                                <td>
                                    <input type="submit" class="btn-primary" value="OCUPAR">
                                    <a href="cobro-estacionamiento.php?codigoParqueadero=<?php echo $datoEstacionamiento->codigo_parqueadero; ?>&codigo-estacionamiento=<?php echo $datoEstacionamiento->codigo_estacionamiento; ?>">COBRAR</a>
                                </td>
                            </form>
                        </tr>

                    <?php
                    }
                    ?>

                </tbody>
            </table>
        </div>
    </div>
</div>





<?php include 'views/footer.php' ?>